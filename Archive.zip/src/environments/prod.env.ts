import { Environment } from "./env";

export const ProddEnvironment: Environment = {
    db_url : 'mongodb+srv://advait:advait@cluster0.u7fqnvx.mongodb.net/?retryWrites=true&w=majority',
    jwt_secret: 'secret'
}